
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0"
import Stripe from "https://esm.sh/stripe@12.18.0"

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
    )

    // Get request body
    const { items, customer_email, shipping_address } = await req.json()

    console.log("Creating checkout session for:", customer_email)
    console.log("Items:", items)
    console.log("Shipping address:", shipping_address)

    if (!items || !items.length) {
      console.error("No items provided in request")
      return new Response(
        JSON.stringify({ error: "No items provided" }),
        { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 400
        }
      )
    }

    // Initialize Stripe
    const stripeKey = Deno.env.get('STRIPE_SECRET_KEY')
    if (!stripeKey) {
      console.error("Stripe secret key not configured")
      return new Response(
        JSON.stringify({ error: "Payment service not configured" }),
        { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 500
        }
      )
    }

    const stripe = new Stripe(stripeKey, {
      apiVersion: '2023-10-16',
    });
    
    // Calculate order total
    const total_amount = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    
    // Generate unique payment ID
    const payment_id = `order_${Date.now()}`;
    
    // Create order using the guest order function
    const { data: orderId, error: orderError } = await supabaseClient
      .rpc('create_guest_order', { 
        p_total_amount: total_amount,
        p_shipping_address: shipping_address,
        p_payment_id: payment_id
      })
    
    if (orderError) {
      console.error("Error creating order:", orderError)
      return new Response(
        JSON.stringify({ error: "Failed to create order", details: orderError }),
        { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 500
        }
      )
    }
    
    if (!orderId) {
      console.error("No order ID returned")
      return new Response(
        JSON.stringify({ error: "Failed to create order - no order ID returned" }),
        { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 500
        }
      )
    }
    
    console.log("Order created:", orderId)

    // Create order items
    const orderItems = items.map(item => ({
      order_id: orderId,
      product_id: item.id,  // Use the item ID directly
      quantity: item.quantity,
      price: item.price,
    }));
    
    console.log("Creating order items:", orderItems);

    // Insert order items
    const { error: itemsError } = await supabaseClient
      .from('order_items')
      .insert(orderItems);

    if (itemsError) {
      console.error("Error creating order items:", itemsError);
      // Continue with checkout even if order items failed - we'll handle it in the success page
    }

    // Create a Stripe checkout session
    console.log("Creating Stripe checkout session");
    
    const origin = new URL(req.url).origin;
    const successUrl = `${origin}/checkout-success?order_id=${orderId}`;
    const cancelUrl = `${origin}/checkout`;
    
    console.log("Success URL:", successUrl);
    console.log("Cancel URL:", cancelUrl);
    
    try {
      // Create line items for Stripe checkout
      const lineItems = items.map(item => ({
        price_data: {
          currency: 'usd',
          product_data: {
            name: item.title || item.name,
            images: item.image ? [item.image] : [],
          },
          unit_amount: Math.round(item.price * 100), // Stripe uses cents
        },
        quantity: item.quantity,
      }));

      console.log("Line items for Stripe:", lineItems);
      
      const session = await stripe.checkout.sessions.create({
        payment_method_types: ['card'],
        line_items: lineItems,
        mode: 'payment',
        success_url: successUrl,
        cancel_url: cancelUrl,
        customer_email: customer_email,
      });
      
      console.log("Stripe checkout session created:", session.id);
      console.log("Checkout URL:", session.url);
      
      // Update the order with Stripe session ID
      await supabaseClient
        .from('orders')
        .update({ payment_id: session.id })
        .eq('id', orderId);
      
      return new Response(
        JSON.stringify({ 
          success: true, 
          url: session.url,
          order_id: orderId
        }),
        { 
          headers: { 
            ...corsHeaders, 
            'Content-Type': 'application/json' 
          } 
        }
      )
    } catch (stripeError) {
      console.error("Stripe error:", stripeError);
      return new Response(
        JSON.stringify({ 
          error: `Stripe error: ${stripeError.message}`,
          stack: stripeError.stack
        }),
        { 
          headers: { 
            ...corsHeaders, 
            'Content-Type': 'application/json' 
          },
          status: 500
        }
      )
    }
  } catch (error) {
    console.error("Error processing checkout:", error)
    
    return new Response(
      JSON.stringify({ 
        error: error.message,
        stack: error.stack
      }),
      { 
        headers: { 
          ...corsHeaders, 
          'Content-Type': 'application/json' 
        },
        status: 500
      }
    )
  }
})

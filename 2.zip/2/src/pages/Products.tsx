
import React from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ProductGrid from '@/components/ProductGrid';
import { products } from '@/lib/products';

const Products: React.FC = () => {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-1 pt-24">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h1 className="text-3xl md:text-4xl font-bold">Our Collection</h1>
            <p className="text-muted-foreground mt-4">
              Browse our curated selection of premium products designed for the modern minimalist lifestyle.
            </p>
          </div>
          
          <ProductGrid products={products} />
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Products;

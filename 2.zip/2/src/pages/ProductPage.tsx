
import React, { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ProductDetail from '@/components/ProductDetail';
import ProductGrid from '@/components/ProductGrid';
import { ProductType, getProductById, products } from '@/lib/products';
import { ChevronLeft } from 'lucide-react';

const ProductPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [product, setProduct] = useState<ProductType | null>(null);
  const [relatedProducts, setRelatedProducts] = useState<ProductType[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const navigate = useNavigate();

  useEffect(() => {
    if (id) {
      // Get product by ID
      const productId = parseInt(id);
      const foundProduct = getProductById(productId);
      
      if (foundProduct) {
        setProduct(foundProduct);
        
        // Get related products (same category)
        const related = products
          .filter(p => p.category === foundProduct.category && p.id !== foundProduct.id)
          .slice(0, 4);
        
        setRelatedProducts(related);
      } else {
        // Product not found, redirect to products page
        navigate('/products');
      }
    }
    
    setLoading(false);
  }, [id, navigate]);

  if (loading) {
    return (
      <div className="flex flex-col min-h-screen">
        <Header />
        <main className="flex-1 pt-24 flex items-center justify-center">
          <div className="animate-pulse-slow">Loading...</div>
        </main>
        <Footer />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="flex flex-col min-h-screen">
        <Header />
        <main className="flex-1 pt-24 flex items-center justify-center">
          <div>Product not found</div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-1 pt-24">
        <div className="container mx-auto px-4">
          {/* Breadcrumbs */}
          <div className="py-4">
            <Link to="/products" className="text-sm text-muted-foreground hover:text-primary flex items-center">
              <ChevronLeft size={14} className="mr-1" />
              Back to Products
            </Link>
          </div>
          
          {/* Product detail */}
          <ProductDetail product={product} />
          
          {/* Related products */}
          {relatedProducts.length > 0 && (
            <div className="mt-16 mb-12">
              <h2 className="text-2xl font-bold mb-8">You may also like</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 md:gap-8">
                {relatedProducts.map(product => (
                  <div key={product.id} className="product-card">
                    <Link to={`/product/${product.id}`}>
                      {/* Product image */}
                      <div className="aspect-square rounded-lg overflow-hidden bg-secondary/30">
                        <img 
                          src={product.image} 
                          alt={product.title} 
                          className="w-full h-full object-contain p-6"
                        />
                      </div>
                      
                      {/* Product info */}
                      <div className="mt-4">
                        <h3 className="font-medium line-clamp-1">{product.title}</h3>
                        <p className="text-muted-foreground mt-1">${product.price.toFixed(2)}</p>
                      </div>
                    </Link>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default ProductPage;

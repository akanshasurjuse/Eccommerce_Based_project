import React from "react";
import Hero from "@/components/Hero";
import ProductGrid from "@/components/ProductGrid";
import { products } from "@/lib/products";
import { Separator } from "@/components/ui/separator";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const Index: React.FC = () => {
  // Get a selection of featured products
  const featuredProducts = products.slice(0, 4);

  return (
    <div className="flex flex-col min-h-screen">
      <Header />

      <main className="flex-1 pt-16">
        {/* Hero section */}
        <Hero />

        {/* Featured products section */}
        <section className="py-16 bg-secondary/30">
          <div className="container mx-auto px-4 text-center">
            <span className="text-sm text-muted-foreground uppercase tracking-widest">
              Collection
            </span>
            <h2 className="text-3xl md:text-4xl font-bold mt-2 mb-4">
              Featured Products
            </h2>
            <p className="text-muted-foreground max-w-lg mx-auto mb-12">
              Discover our most popular products, selected for their exceptional
              design and quality craftsmanship.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
              {featuredProducts.map((product) => (
                <div key={product.id} className="product-card animate-fade-in">
                  {/* Product image */}
                  <div className="aspect-square rounded-lg overflow-hidden bg-white/50 dark:bg-white/5">
                    <img
                      src={product.image}
                      alt={product.title}
                      className="w-full h-full object-contain p-6"
                    />
                  </div>

                  {/* Product info */}
                  <div className="mt-4 text-center">
                    <h3 className="font-medium line-clamp-1">
                      {product.title}
                    </h3>
                    <p className="text-muted-foreground mt-1">
                      ${product.price.toFixed(2)}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* About section */}
        <section className="py-24">
          <div className="container mx-auto px-4 max-w-5xl">
            <div className="flex flex-col md:flex-row items-center gap-12">
              <div className="w-full md:w-1/2">
                <div className="relative aspect-square">
                  <div className="absolute inset-0 rounded-lg overflow-hidden">
                    <img
                      src="https://thumbs.dreamstime.com/z/misty-forest-suspension-bridge-dark-gritty-northwest-school-landscape-old-wooden-bridge-style-dark-emerald-286342644.jpg?ct=jpeg"
                      alt="Our story"
                      className="w-full h-full object-cover"
                    />
                  </div>

                  {/* Decorative elements */}
                  <div className="absolute -bottom-6 -left-6 w-24 h-24 bg-secondary rounded-lg -z-10"></div>
                  <div className="absolute -top-6 -right-6 w-32 h-32 border border-primary/20 rounded-lg -z-10"></div>
                </div>
              </div>

              <div className="w-full md:w-1/2 space-y-6">
                <span className="text-sm text-muted-foreground uppercase tracking-widest">
                  Our Story
                </span>
                <h2 className="text-3xl md:text-4xl font-bold">
                  Crafted with purpose
                </h2>

                <Separator />

                <p className="text-muted-foreground">
                  We believe in the power of thoughtful design. Each product in
                  our collection is carefully selected for its ability to bring
                  function, beauty, and joy to everyday life.
                </p>

                <p className="text-muted-foreground">
                  Our commitment to quality means we partner with skilled
                  craftspeople and responsible manufacturers who share our
                  values of sustainability and excellence.
                </p>

                <button className="btn-primary mt-4">Learn More</button>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default Index;

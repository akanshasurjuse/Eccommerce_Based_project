
import React from 'react';
import { Link } from 'react-router-dom';
import { Trash2, Plus, Minus, ArrowRight } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { useCart } from '@/context/CartContext';

const CartPage: React.FC = () => {
  const { cart, removeFromCart, updateQuantity, cartTotal } = useCart();

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(price);
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-1 pt-24">
        <div className="container mx-auto px-4 py-12">
          <h1 className="text-3xl font-bold mb-8">Shopping Cart</h1>
          
          {cart.length === 0 ? (
            <div className="text-center py-12 bg-secondary/30 rounded-lg">
              <p className="text-muted-foreground mb-6">Your cart is empty</p>
              <Button asChild>
                <Link to="/products">Continue Shopping</Link>
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Cart items */}
              <div className="lg:col-span-2 space-y-4">
                {/* Header */}
                <div className="hidden md:grid grid-cols-12 gap-4 py-2 border-b text-sm text-muted-foreground">
                  <div className="col-span-6">Product</div>
                  <div className="col-span-2 text-center">Price</div>
                  <div className="col-span-2 text-center">Quantity</div>
                  <div className="col-span-2 text-right">Total</div>
                </div>
                
                {/* Items */}
                {cart.map(item => (
                  <div 
                    key={item.id} 
                    className="grid grid-cols-1 md:grid-cols-12 gap-4 p-4 border rounded-lg animate-fade-in"
                  >
                    {/* Product */}
                    <div className="col-span-6 flex gap-4">
                      {/* Image */}
                      <div className="w-20 h-20 bg-secondary/30 rounded-md overflow-hidden flex-shrink-0">
                        <img 
                          src={item.image} 
                          alt={item.title} 
                          className="w-full h-full object-cover"
                        />
                      </div>
                      
                      {/* Info */}
                      <div className="flex flex-col justify-between">
                        <div>
                          <h3 className="font-medium line-clamp-1">{item.title}</h3>
                          <p className="text-sm text-muted-foreground mt-1 md:hidden">
                            {formatPrice(item.price)}
                          </p>
                        </div>
                        
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="text-muted-foreground justify-start p-0 h-auto hover:text-destructive md:hidden"
                          onClick={() => removeFromCart(item.id)}
                        >
                          <Trash2 size={14} className="mr-1" />
                          Remove
                        </Button>
                      </div>
                    </div>
                    
                    {/* Price */}
                    <div className="hidden md:flex col-span-2 items-center justify-center">
                      {formatPrice(item.price)}
                    </div>
                    
                    {/* Quantity */}
                    <div className="col-span-2 flex items-center justify-center md:justify-center">
                      <div className="flex border rounded-md overflow-hidden">
                        <Button 
                          variant="ghost"
                          className="rounded-none h-8 w-8 p-0"
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          disabled={item.quantity <= 1}
                        >
                          <Minus size={14} />
                        </Button>
                        <div className="flex items-center justify-center w-10 border-x">
                          {item.quantity}
                        </div>
                        <Button 
                          variant="ghost"
                          className="rounded-none h-8 w-8 p-0"
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        >
                          <Plus size={14} />
                        </Button>
                      </div>
                    </div>
                    
                    {/* Total & Remove */}
                    <div className="col-span-2 flex items-center justify-between md:justify-end">
                      <span className="font-medium">
                        {formatPrice(item.price * item.quantity)}
                      </span>
                      
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="hidden md:flex text-muted-foreground hover:text-destructive h-8 w-8"
                        onClick={() => removeFromCart(item.id)}
                      >
                        <Trash2 size={14} />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
              
              {/* Order summary */}
              <div className="lg:col-span-1">
                <div className="border rounded-lg p-6 space-y-4 sticky top-24">
                  <h2 className="font-semibold text-xl">Order Summary</h2>
                  
                  <div className="space-y-2 pb-4">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Subtotal</span>
                      <span>{formatPrice(cartTotal)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Shipping</span>
                      <span>Free</span>
                    </div>
                  </div>
                  
                  <Separator />
                  
                  <div className="flex justify-between font-semibold text-lg pt-2">
                    <span>Total</span>
                    <span>{formatPrice(cartTotal)}</span>
                  </div>
                  
                  <Button className="w-full mt-4 group" asChild>
                    <Link to="/checkout">
                      Checkout <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                    </Link>
                  </Button>
                  
                  <p className="text-sm text-muted-foreground text-center pt-4">
                    Secure checkout powered by Stripe
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default CartPage;


import React, { useEffect, useState } from 'react';
import { Link, useSearchParams, useLocation } from 'react-router-dom';
import { Check, ShoppingBag, Clock } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { Button } from '@/components/ui/button';
import { useCart } from '@/context/CartContext';
import { supabase } from '@/integrations/supabase/client';

const CheckoutSuccessPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const location = useLocation();
  const [orderStatus, setOrderStatus] = useState<string | null>(null);
  const [orderItems, setOrderItems] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { clearCart } = useCart();
  
  // Get orderId from URL params, location state, or localStorage
  const orderIdFromParams = searchParams.get('order_id');
  const orderIdFromState = location.state?.orderId;
  const orderIdFromStorage = localStorage.getItem('latestOrderId');
  const orderId = orderIdFromParams || orderIdFromState || orderIdFromStorage;
  
  useEffect(() => {
    // Clear the cart on successful checkout
    clearCart();
    
    // Clear the localStorage item now that we've used it
    if (orderIdFromStorage) {
      localStorage.removeItem('latestOrderId');
    }
    
    // Fetch order status if orderId exists
    if (orderId) {
      fetchOrderStatus();
      fetchOrderItems();
    } else {
      setIsLoading(false);
    }
  }, [clearCart, orderId]);
  
  const fetchOrderStatus = async () => {
    try {
      setIsLoading(true);
      const { data, error } = await supabase
        .from('orders')
        .select('status')
        .eq('id', orderId)
        .single();
        
      if (error) {
        console.error('Error fetching order:', error);
      } else if (data) {
        setOrderStatus(data.status);
        
        // If payment was successful, update order status to 'paid'
        if (data.status === 'pending') {
          await supabase
            .from('orders')
            .update({ status: 'paid' })
            .eq('id', orderId);
            
          setOrderStatus('paid');
        }
      }
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setIsLoading(false);
    }
  };
  
  const fetchOrderItems = async () => {
    try {
      const { data, error } = await supabase
        .from('order_items')
        .select(`
          quantity,
          price,
          products (
            name,
            image
          )
        `)
        .eq('order_id', orderId);
        
      if (error) {
        console.error('Error fetching order items:', error);
      } else if (data) {
        setOrderItems(data);
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(price);
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-1 pt-24">
        <div className="container mx-auto px-4 py-12">
          <div className="max-w-md mx-auto text-center">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              {isLoading ? (
                <Clock className="h-10 w-10 text-green-600 animate-spin" />
              ) : (
                <Check className="h-10 w-10 text-green-600" />
              )}
            </div>
            
            <h1 className="text-3xl font-bold mb-2">Payment Successful!</h1>
            <p className="text-muted-foreground mb-6">
              Thank you for your purchase. Your order has been confirmed.
              {orderId && <span className="block mt-2">Order ID: {orderId}</span>}
              {orderStatus && <span className="block mt-1">Status: {orderStatus}</span>}
            </p>
            
            {/* Order Summary */}
            {orderItems.length > 0 && (
              <div className="mt-8 mb-8 border rounded-lg p-4 text-left">
                <h2 className="text-xl font-semibold mb-4 text-center">Order Summary</h2>
                <div className="space-y-4">
                  {orderItems.map((item, index) => (
                    <div key={index} className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-secondary/30 rounded-md overflow-hidden flex-shrink-0">
                        {item.products?.image && (
                          <img 
                            src={item.products.image} 
                            alt={item.products.name} 
                            className="w-full h-full object-cover"
                            onError={(e) => {
                              (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1488590528505-98d2b5aba04b?q=80&w=1000&auto=format&fit=crop';
                            }}
                          />
                        )}
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">{item.products?.name || 'Product'}</p>
                        <p className="text-xs text-muted-foreground">Qty: {item.quantity}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium">{formatPrice(item.price * item.quantity)}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            <div className="space-y-3">
              <Button asChild className="w-full">
                <Link to="/products">
                  <ShoppingBag className="mr-2 h-4 w-4" />
                  Continue Shopping
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default CheckoutSuccessPage;


export interface ProductType {
  id: number;
  title: string;
  price: number;
  description: string;
  category: string;
  image: string;
  stock?: number;
  rating: {
    rate: number;
    count: number;
  };
}

// Function to generate random stock levels
const getRandomStock = (min = 0, max = 30) => {
  return Math.floor(Math.random() * (max - min + 1)) + min;
};

export const products: ProductType[] = [
  {
    id: 1,
    title: "Premium Wireless Earbuds",
    price: 149.99,
    description: "Exceptional sound quality with active noise cancellation. Sleek design with premium materials and up to 24 hours of battery life with charging case.",
    category: "electronics",
    image: "https://images.unsplash.com/photo-1606220945770-b5b6c2c55bf1?q=80&w=1000&auto=format&fit=crop&ixlib=rb-4.0.3",
    stock: 15,
    rating: {
      rate: 4.8,
      count: 128
    }
  },
  {
    id: 2,
    title: "Minimalist Leather Watch",
    price: 199.95,
    description: "Sophisticated timepiece with a clean, minimalist design. Premium leather strap and stainless steel case with Japanese movement.",
    category: "accessories",
    image: "https://images.unsplash.com/photo-1524592094714-0f0654e20314?q=80&w=1000&auto=format&fit=crop",
    stock: 12,
    rating: {
      rate: 4.7,
      count: 94
    }
  },
  {
    id: 3,
    title: "Smart Home Speaker",
    price: 129.00,
    description: "Intelligent speaker with premium sound quality and voice assistant integration. Modern design that complements any interior style.",
    category: "electronics",
    image: "https://images.unsplash.com/photo-1545454675-3531b543be5d?q=80&w=1000&auto=format&fit=crop",
    stock: 8,
    rating: {
      rate: 4.5,
      count: 76
    }
  },
  {
    id: 4,
    title: "Ergonomic Office Chair",
    price: 349.99,
    description: "Premium ergonomic chair designed for optimal comfort during long work sessions. Adjustable lumbar support and breathable mesh material.",
    category: "furniture",
    image: "https://images.unsplash.com/photo-1580480055273-228ff5388ef8?q=80&w=1000&auto=format&fit=crop",
    stock: 5,
    rating: {
      rate: 4.6,
      count: 43
    }
  },
  {
    id: 5,
    title: "Professional Camera Lens",
    price: 899.95,
    description: "High-performance telephoto lens for professional photographers. Exceptional clarity and bokeh with weather-sealed construction.",
    category: "electronics",
    image: "https://images.unsplash.com/photo-1617005082099-bb509ef1ad5a?q=80&w=1000&auto=format&fit=crop",
    stock: 3,
    rating: {
      rate: 4.9,
      count: 61
    }
  },
  {
    id: 6,
    title: "Premium Coffee Maker",
    price: 199.00,
    description: "Precision brewing system with temperature control for the perfect cup every time. Elegant design with premium materials.",
    category: "home",
    image: "https://images.unsplash.com/photo-1606483956061-46a898dce538?q=80&w=1000&auto=format&fit=crop",
    stock: 10,
    rating: {
      rate: 4.6,
      count: 87
    }
  },
  {
    id: 7,
    title: "Wireless Charging Pad",
    price: 59.99,
    description: "Fast wireless charging with minimalist design. Works with all Qi-enabled devices and features smart temperature management.",
    category: "electronics",
    image: "https://images.unsplash.com/photo-1608479326933-8c861ca0d9e3?q=80&w=1000&auto=format&fit=crop",
    stock: 20,
    rating: {
      rate: 4.3,
      count: 112
    }
  },
  {
    id: 8,
    title: "Designer Desk Lamp",
    price: 129.95,
    description: "Architecturally inspired desk lamp with adjustable brightness and color temperature. Premium materials with a timeless design.",
    category: "home",
    image: "https://images.unsplash.com/photo-1621739039415-df26ac646831?q=80&w=1000&auto=format&fit=crop",
    stock: 8,
    rating: {
      rate: 4.4,
      count: 53
    }
  },
  // Adding 20 more products with proper images and categories
  {
    id: 9,
    title: "Mechanical Keyboard",
    price: 149.99,
    description: "Premium mechanical keyboard with customizable RGB lighting and tactile switches for the ultimate typing experience.",
    category: "electronics",
    image: "https://images.unsplash.com/photo-1587829741301-dc798b83add3?q=80&w=1000&auto=format&fit=crop",
    stock: getRandomStock(),
    rating: {
      rate: 4.6,
      count: 82
    }
  },
  {
    id: 10,
    title: "Ultra-thin Laptop",
    price: 1299.99,
    description: "Powerful yet lightweight laptop with all-day battery life and stunning 4K display.",
    category: "electronics",
    image: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?q=80&w=1000&auto=format&fit=crop",
    stock: getRandomStock(),
    rating: {
      rate: 4.8,
      count: 123
    }
  },
  {
    id: 11,
    title: "Fitness Smartwatch",
    price: 229.99,
    description: "Advanced fitness tracker with heart rate monitoring, GPS, and a week-long battery life.",
    category: "electronics",
    image: "https://images.unsplash.com/photo-1579586337278-3befd40fd17a?q=80&w=1000&auto=format&fit=crop",
    stock: getRandomStock(),
    rating: {
      rate: 4.5,
      count: 95
    }
  },
  {
    id: 12,
    title: "Leather Messenger Bag",
    price: 179.95,
    description: "Handcrafted genuine leather messenger bag with multiple compartments and adjustable strap.",
    category: "accessories",
    image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?q=80&w=1000&auto=format&fit=crop",
    stock: getRandomStock(),
    rating: {
      rate: 4.7,
      count: 68
    }
  },
  {
    id: 13,
    title: "Premium Noise-Cancelling Headphones",
    price: 299.99,
    description: "Over-ear headphones with industry-leading noise cancellation and 30 hours of battery life.",
    category: "electronics",
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?q=80&w=1000&auto=format&fit=crop",
    stock: getRandomStock(),
    rating: {
      rate: 4.9,
      count: 145
    }
  },
  {
    id: 14,
    title: "Minimalist Wall Clock",
    price: 49.99,
    description: "Sleek and modern wall clock with silent movement and minimalist design.",
    category: "home",
    image: "https://images.unsplash.com/photo-1544139126-748d8a84c9b8?q=80&w=1000&auto=format&fit=crop",
    stock: getRandomStock(),
    rating: {
      rate: 4.2,
      count: 57
    }
  },
  {
    id: 15,
    title: "Smart Video Doorbell",
    price: 159.99,
    description: "HD video doorbell with motion detection, two-way audio, and night vision.",
    category: "electronics",
    image: "https://images.unsplash.com/photo-1595264831574-1f458d598a5c?q=80&w=1000&auto=format&fit=crop",
    stock: getRandomStock(),
    rating: {
      rate: 4.5,
      count: 92
    }
  },
  {
    id: 16,
    title: "Ceramic Pour-Over Coffee Set",
    price: 79.95,
    description: "Handcrafted ceramic pour-over coffee set with wooden stand and reusable filter.",
    category: "home",
    image: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?q=80&w=1000&auto=format&fit=crop",
    stock: getRandomStock(),
    rating: {
      rate: 4.4,
      count: 48
    }
  },
  {
    id: 17,
    title: "Bamboo Bath Caddy",
    price: 39.99,
    description: "Extendable bamboo bath caddy with wine glass holder, book stand, and phone slot.",
    category: "home",
    image: "https://images.unsplash.com/photo-1646704567905-177a02b8e185?q=80&w=1000&auto=format&fit=crop",
    stock: getRandomStock(),
    rating: {
      rate: 4.3,
      count: 63
    }
  },
  {
    id: 18,
    title: "Portable Bluetooth Speaker",
    price: 89.99,
    description: "Waterproof Bluetooth speaker with 360° sound and 12-hour battery life.",
    category: "electronics",
    image: "https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?q=80&w=1000&auto=format&fit=crop",
    stock: getRandomStock(),
    rating: {
      rate: 4.6,
      count: 105
    }
  },
  {
    id: 19,
    title: "Organic Cotton Throw Blanket",
    price: 69.95,
    description: "Soft and cozy throw blanket made from 100% organic cotton in a stylish herringbone pattern.",
    category: "home",
    image: "https://images.unsplash.com/photo-1580376259349-5f4b7db4c39f?q=80&w=1000&auto=format&fit=crop",
    stock: getRandomStock(),
    rating: {
      rate: 4.5,
      count: 78
    }
  },
  {
    id: 20,
    title: "Leather Portfolio Case",
    price: 59.99,
    description: "Professional leather portfolio with multiple pockets for documents, cards, and a tablet.",
    category: "accessories",
    image: "https://images.unsplash.com/photo-1506634064465-7dab4de896ed?q=80&w=1000&auto=format&fit=crop",
    stock: getRandomStock(),
    rating: {
      rate: 4.2,
      count: 41
    }
  },
  {
    id: 21,
    title: "Stainless Steel Water Bottle",
    price: 34.99,
    description: "Vacuum-insulated water bottle that keeps drinks cold for 24 hours or hot for 12 hours.",
    category: "accessories",
    image: "https://images.unsplash.com/photo-1602143407151-7111542de6e8?q=80&w=1000&auto=format&fit=crop",
    stock: getRandomStock(),
    rating: {
      rate: 4.7,
      count: 89
    }
  },
  {
    id: 22,
    title: "Minimalist Ceramic Planter",
    price: 29.95,
    description: "Set of 3 minimalist ceramic planters with bamboo trays, perfect for succulents and small plants.",
    category: "home",
    image: "https://images.unsplash.com/photo-1485955900006-10f4d324d411?q=80&w=1000&auto=format&fit=crop",
    stock: getRandomStock(),
    rating: {
      rate: 4.3,
      count: 64
    }
  },
  {
    id: 23,
    title: "Smart Wi-Fi Light Bulbs",
    price: 49.99,
    description: "Set of 4 color-changing smart bulbs controllable via app or voice commands.",
    category: "electronics",
    image: "https://images.unsplash.com/photo-1550985543-f1ea83b176e6?q=80&w=1000&auto=format&fit=crop",
    stock: getRandomStock(),
    rating: {
      rate: 4.4,
      count: 72
    }
  },
  {
    id: 24,
    title: "Handwoven Wall Hanging",
    price: 89.95,
    description: "Artisanal wall hanging handwoven from natural fibers with a modern geometric design.",
    category: "home",
    image: "https://images.unsplash.com/photo-1615800001964-5afd0ae8e49a?q=80&w=1000&auto=format&fit=crop",
    stock: getRandomStock(),
    rating: {
      rate: 4.6,
      count: 53
    }
  },
  {
    id: 25,
    title: "Wireless Gaming Mouse",
    price: 79.99,
    description: "High-precision wireless gaming mouse with programmable buttons and adjustable DPI.",
    category: "electronics",
    image: "https://images.unsplash.com/photo-1615655406736-b37c4fabf923?q=80&w=1000&auto=format&fit=crop",
    stock: getRandomStock(),
    rating: {
      rate: 4.8,
      count: 112
    }
  },
  {
    id: 26,
    title: "Handcrafted Leather Wallet",
    price: 49.95,
    description: "Slim, minimalist wallet handcrafted from full-grain leather with RFID protection.",
    category: "accessories",
    image: "https://images.unsplash.com/photo-1604026094782-17a8db012d75?q=80&w=1000&auto=format&fit=crop",
    stock: getRandomStock(),
    rating: {
      rate: 4.5,
      count: 78
    }
  },
  {
    id: 27,
    title: "Aromatherapy Diffuser",
    price: 49.99,
    description: "Ultrasonic essential oil diffuser with 7 LED light colors and automatic shut-off.",
    category: "home",
    image: "https://images.unsplash.com/photo-1608571423539-e951a77694e5?q=80&w=1000&auto=format&fit=crop",
    stock: getRandomStock(),
    rating: {
      rate: 4.4,
      count: 95
    }
  },
  {
    id: 28,
    title: "Artisanal Ceramic Mug Set",
    price: 39.99,
    description: "Set of 4 handcrafted ceramic mugs, each with a unique glaze pattern.",
    category: "home",
    image: "https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?q=80&w=1000&auto=format&fit=crop",
    stock: getRandomStock(),
    rating: {
      rate: 4.3,
      count: 67
    }
  }
];

export const getProductById = (id: number): ProductType | undefined => {
  return products.find(product => product.id === id);
};

export const getProductsByCategory = (category: string): ProductType[] => {
  if (category === 'all') return products;
  return products.filter(product => product.category === category);
};

export const getCategories = (): string[] => {
  const categories = products.map(product => product.category);
  return ['all', ...new Set(categories)];
};

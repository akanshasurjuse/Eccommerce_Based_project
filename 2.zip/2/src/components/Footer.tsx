
import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Twitter, Instagram, Youtube, ChevronRight } from 'lucide-react';
import { Separator } from '@/components/ui/separator';

const Footer: React.FC = () => {
  return (
    <footer className="bg-secondary/50 dark:bg-secondary/20 pt-16 pb-8">
      <div className="container mx-auto px-4">
        {/* Top section */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* About */}
          <div>
            <h3 className="font-semibold text-lg mb-4">Minimalist</h3>
            <p className="text-muted-foreground text-sm mb-4">
              Curated collection of premium products for the modern minimalist. Quality craftsmanship with elegant design.
            </p>
            
            {/* Social icons */}
            <div className="flex gap-4">
              <a href="#" className="btn-icon text-muted-foreground hover:text-primary">
                <Facebook size={18} />
              </a>
              <a href="#" className="btn-icon text-muted-foreground hover:text-primary">
                <Twitter size={18} />
              </a>
              <a href="#" className="btn-icon text-muted-foreground hover:text-primary">
                <Instagram size={18} />
              </a>
              <a href="#" className="btn-icon text-muted-foreground hover:text-primary">
                <Youtube size={18} />
              </a>
            </div>
          </div>
          
          {/* Links */}
          <div>
            <h3 className="font-semibold text-lg mb-4">Shop</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link to="/products" className="text-muted-foreground hover:text-primary flex items-center">
                  <ChevronRight size={14} className="mr-1" />
                  All Products
                </Link>
              </li>
              <li>
                <Link to="/products?category=electronics" className="text-muted-foreground hover:text-primary flex items-center">
                  <ChevronRight size={14} className="mr-1" />
                  Electronics
                </Link>
              </li>
              <li>
                <Link to="/products?category=home" className="text-muted-foreground hover:text-primary flex items-center">
                  <ChevronRight size={14} className="mr-1" />
                  Home
                </Link>
              </li>
              <li>
                <Link to="/products?category=accessories" className="text-muted-foreground hover:text-primary flex items-center">
                  <ChevronRight size={14} className="mr-1" />
                  Accessories
                </Link>
              </li>
            </ul>
          </div>
          
          {/* Links */}
          <div>
            <h3 className="font-semibold text-lg mb-4">Information</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#" className="text-muted-foreground hover:text-primary flex items-center">
                  <ChevronRight size={14} className="mr-1" />
                  About Us
                </a>
              </li>
              <li>
                <a href="#" className="text-muted-foreground hover:text-primary flex items-center">
                  <ChevronRight size={14} className="mr-1" />
                  Contact Us
                </a>
              </li>
              <li>
                <a href="#" className="text-muted-foreground hover:text-primary flex items-center">
                  <ChevronRight size={14} className="mr-1" />
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="#" className="text-muted-foreground hover:text-primary flex items-center">
                  <ChevronRight size={14} className="mr-1" />
                  Terms & Conditions
                </a>
              </li>
            </ul>
          </div>
          
          {/* Newsletter */}
          <div>
            <h3 className="font-semibold text-lg mb-4">Newsletter</h3>
            <p className="text-muted-foreground text-sm mb-4">
              Subscribe to our newsletter to receive updates and exclusive offers.
            </p>
            
            <div className="flex">
              <input 
                type="email" 
                placeholder="Your email" 
                className="flex h-10 w-full rounded-l-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
              />
              <button className="h-10 rounded-r-md bg-primary px-4 text-primary-foreground hover:opacity-90 transition-opacity">
                Join
              </button>
            </div>
          </div>
        </div>
        
        <Separator />
        
        {/* Bottom section */}
        <div className="flex flex-col md:flex-row justify-between items-center mt-8 text-sm text-muted-foreground">
          <p>© {new Date().getFullYear()} Minimalist. All rights reserved.</p>
          
          <div className="flex gap-4 mt-4 md:mt-0">
            <a href="#" className="hover:text-primary">Privacy Policy</a>
            <a href="#" className="hover:text-primary">Terms of Service</a>
            <a href="#" className="hover:text-primary">Cookies Settings</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

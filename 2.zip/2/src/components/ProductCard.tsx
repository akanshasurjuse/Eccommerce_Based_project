
import React from 'react';
import { Link } from 'react-router-dom';
import { Eye, ShoppingCart, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ProductType } from '@/lib/products';
import { useCart } from '@/context/CartContext';
import { Badge } from '@/components/ui/badge';

interface ProductCardProps {
  product: ProductType;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { addToCart } = useCart();
  
  const { id, title, price, image, rating, stock } = product;

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(price);
  };

  const getLowStockStatus = () => {
    if (stock === 0) return { color: 'bg-red-500', text: 'Out of Stock' };
    if (stock < 5) return { color: 'bg-orange-500', text: `Low Stock: ${stock} left` };
    return { color: 'bg-green-500', text: `In Stock: ${stock}` };
  };

  const stockStatus = getLowStockStatus();

  return (
    <div className="product-card group animate-fade-in">
      {/* Product image wrapper */}
      <div className="relative overflow-hidden rounded-lg aspect-square bg-secondary/30">
        <img 
          src={image} 
          alt={title} 
          className="w-full h-full object-cover object-center transition-transform duration-500 group-hover:scale-105"
          loading="lazy"
          onError={(e) => {
            (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1488590528505-98d2b5aba04b?q=80&w=1000&auto=format&fit=crop';
          }}
        />
        
        {/* Stock badge */}
        <div className="absolute top-2 right-2">
          <Badge className={`${stockStatus.color} text-white`}>
            {stockStatus.text}
          </Badge>
        </div>
        
        {/* Quick actions overlay */}
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors duration-300 flex items-center justify-center opacity-0 group-hover:opacity-100">
          <div className="flex gap-2 scale-90 group-hover:scale-100 transition-transform duration-300">
            <Button 
              size="icon"
              variant="secondary"
              className="rounded-full bg-white/90 hover:bg-white shadow-md"
              onClick={(e) => {
                e.preventDefault();
                if (stock > 0) {
                  addToCart(product);
                } else {
                  e.stopPropagation();
                }
              }}
              disabled={stock === 0}
              title={stock === 0 ? "Out of stock" : "Add to cart"}
            >
              {stock === 0 ? <AlertCircle size={18} /> : <ShoppingCart size={18} />}
            </Button>
            
            <Button 
              size="icon"
              variant="secondary"
              className="rounded-full bg-white/90 hover:bg-white shadow-md"
              asChild
            >
              <Link to={`/product/${id}`}>
                <Eye size={18} />
              </Link>
            </Button>
          </div>
        </div>
      </div>
      
      {/* Product info */}
      <div className="pt-3 space-y-1 text-left">
        <div className="flex items-center justify-between">
          <h3 className="font-medium text-sm sm:text-base line-clamp-1">
            <Link to={`/product/${id}`} className="hover:underline">
              {title}
            </Link>
          </h3>
          
          {/* Rating */}
          <div className="flex items-center text-sm text-muted-foreground">
            <span className="mr-1">★</span>
            <span>{rating.rate}</span>
          </div>
        </div>
        
        <p className="font-semibold">{formatPrice(price)}</p>
      </div>
    </div>
  );
};

export default ProductCard;

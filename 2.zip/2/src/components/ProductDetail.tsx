
import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Star, Truck, Clock, ShieldCheck, Heart, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ProductType } from '@/lib/products';
import { useCart } from '@/context/CartContext';
import { Separator } from '@/components/ui/separator';

interface ProductDetailProps {
  product: ProductType;
}

const ProductDetail: React.FC<ProductDetailProps> = ({ product }) => {
  const [quantity, setQuantity] = useState(1);
  const { addToCart } = useCart();
  
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(price);
  };

  const handleAddToCart = () => {
    for (let i = 0; i < quantity; i++) {
      addToCart(product);
    }
  };

  const handleQuantityChange = (value: number) => {
    if (value >= 1) {
      setQuantity(value);
    }
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="flex flex-col md:flex-row gap-8 lg:gap-12">
        {/* Product image */}
        <div className="w-full md:w-1/2 animate-fade-in">
          <div className="relative aspect-square bg-secondary/30 rounded-lg overflow-hidden">
            <img 
              src={product.image} 
              alt={product.title} 
              className="w-full h-full object-contain p-8"
            />
            
            {/* Image navigation */}
            <div className="absolute inset-x-0 bottom-4 flex justify-center gap-2">
              <Button 
                variant="secondary" 
                size="icon" 
                className="rounded-full bg-background/80 backdrop-blur-sm"
              >
                <ChevronLeft size={16} />
              </Button>
              <Button 
                variant="secondary" 
                size="icon" 
                className="rounded-full bg-background/80 backdrop-blur-sm"
              >
                <ChevronRight size={16} />
              </Button>
            </div>
          </div>
        </div>
        
        {/* Product info */}
        <div className="w-full md:w-1/2 animate-slide-up">
          <div className="space-y-6">
            {/* Category & title */}
            <div>
              <span className="text-sm text-muted-foreground uppercase tracking-wider">
                {product.category}
              </span>
              <h1 className="text-3xl font-bold mt-1">{product.title}</h1>
            </div>
            
            {/* Price & rating */}
            <div className="flex items-center justify-between">
              <span className="text-2xl font-semibold">{formatPrice(product.price)}</span>
              
              <div className="flex items-center gap-1.5">
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <Star 
                      key={i} 
                      size={16} 
                      className={i < Math.round(product.rating.rate) 
                        ? "fill-primary text-primary" 
                        : "text-muted-foreground"
                      } 
                    />
                  ))}
                </div>
                <span className="text-sm text-muted-foreground">
                  ({product.rating.count} reviews)
                </span>
              </div>
            </div>
            
            {/* Description */}
            <p className="text-muted-foreground">{product.description}</p>
            
            <Separator />
            
            {/* Features */}
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center gap-2">
                <Truck size={16} className="text-muted-foreground" />
                <span className="text-sm">Free shipping</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock size={16} className="text-muted-foreground" />
                <span className="text-sm">Same-day delivery</span>
              </div>
              <div className="flex items-center gap-2">
                <ShieldCheck size={16} className="text-muted-foreground" />
                <span className="text-sm">2-year warranty</span>
              </div>
              <div className="flex items-center gap-2">
                <AlertTriangle size={16} className="text-muted-foreground" />
                <span className="text-sm">Only {product.rating.count} left</span>
              </div>
            </div>
            
            <Separator />
            
            {/* Actions */}
            <div className="space-y-4">
              {/* Quantity controls */}
              <div className="flex items-center gap-4">
                <span className="text-sm font-medium">Quantity</span>
                
                <div className="flex border rounded-md overflow-hidden">
                  <Button 
                    variant="ghost"
                    className="rounded-none h-10 px-3"
                    onClick={() => handleQuantityChange(quantity - 1)}
                    disabled={quantity <= 1}
                  >
                    -
                  </Button>
                  <div className="flex items-center justify-center w-12 border-x">
                    {quantity}
                  </div>
                  <Button 
                    variant="ghost"
                    className="rounded-none h-10 px-3"
                    onClick={() => handleQuantityChange(quantity + 1)}
                  >
                    +
                  </Button>
                </div>
              </div>
              
              {/* Buttons */}
              <div className="flex gap-4">
                <Button 
                  className="flex-1"
                  onClick={handleAddToCart}
                >
                  Add to Cart
                </Button>
                
                <Button 
                  variant="outline" 
                  size="icon"
                >
                  <Heart size={18} />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;

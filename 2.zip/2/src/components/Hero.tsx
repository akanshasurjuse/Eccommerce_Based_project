import React from "react";
import { ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

const Hero: React.FC = () => {
  return (
    <div className="relative min-h-[90vh] flex items-center overflow-hidden">
      {/* Background pattern */}
      <div className="absolute inset-0 -z-10 bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] dark:bg-[radial-gradient(#1a1a1a_1px,transparent_1px)] [background-size:20px_20px] opacity-50"></div>

      {/* Content container */}
      <div className="container mx-auto px-4 py-12 flex flex-col lg:flex-row items-center">
        {/* Left text content */}
        <div className="w-full lg:w-1/2 space-y-6 animate-slide-up">
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold tracking-tight">
            <span className="block">One Stop Bazaar</span>
            <span className="block mt-1">For All Your Needs</span>
          </h1>

          <p className="text-muted-foreground text-lg max-w-md">
            Curated collection of premium products for the modern minimalist.
            Quality craftsmanship with elegant design.
          </p>

          <div className="pt-4 flex flex-wrap gap-4">
            <Button size="lg" asChild>
              <Link to="/products">
                Shop Collection <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>

            <Button variant="outline" size="lg">
              Learn More
            </Button>
          </div>
        </div>

        {/* Right image content */}
        <div className="w-full lg:w-1/2 mt-12 lg:mt-0 flex justify-center animate-scale-in">
          <div className="relative w-full max-w-lg lg:max-w-xl aspect-square">
            {/* Main product image */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-[80%] h-[80%] rounded-xl overflow-hidden shadow-xl">
                <img
                  src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTAOAMq61jjZjU8fYwBx99kdIakBpUICFEkFfBLW-Zj_oIKFF1CLTKlbSExJA9EE9_D26s&usqp=CAU"
                  alt="Featured product"
                  className="w-full h-full object-cover object-center"
                />
              </div>
            </div>

            {/* Accent circle */}
            <div className="absolute top-[10%] left-[10%] w-[30%] h-[30%] bg-primary/10 dark:bg-primary/5 rounded-full blur-2xl"></div>

            {/* Decorative elements */}
            <div className="absolute top-[60%] right-[15%] w-16 h-16 rounded-full bg-secondary animate-pulse-slow"></div>
            <div className="absolute bottom-[15%] left-[20%] w-24 h-24 rounded-full border border-primary/20 dark:border-primary/10"></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;

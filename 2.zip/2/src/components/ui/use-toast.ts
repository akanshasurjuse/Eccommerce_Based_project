
import { useToast as useToastHook, toast as toastHook } from "@/hooks/use-toast";

export { useToastHook as useToast, toastHook as toast };
